# 🧮 Calculator Project

A simple command-line calculator built using Python.

## 🚀 Features
- Addition
- Subtraction
- Multiplication
- Division
- Error handling

## 📸 Screenshots
![Calculator Screenshot](screenshot.png)

## ▶️ How to Run
```bash
python calculator.py
```
